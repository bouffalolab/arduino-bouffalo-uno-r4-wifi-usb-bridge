彩色像素图标：笑脸 smile、心形 heart、垃圾桶 trash。
原始网格：32×32；透明 RGBA PNG；提供 32/64/128/256 像素。
放大版本采用最近邻插值，无抗锯齿。
svg/：按像素绘制的可编辑 SVG。
sprite_sheet_96x32.png：从左到右为 smile、heart、trash。
